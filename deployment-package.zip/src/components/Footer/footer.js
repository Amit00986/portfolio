import React from 'react'
import './footer.css'

const Footer = () => {
  return (
    <footer className='footer'>
        copy right
    </footer>
  )
}

export default Footer